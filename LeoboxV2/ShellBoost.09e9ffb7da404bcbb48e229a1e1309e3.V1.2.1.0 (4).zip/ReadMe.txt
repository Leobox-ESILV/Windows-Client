﻿This package contains the ShellBoost binaries, license and this ReadMe.txt file.

Redistributable files:

 * ShellBoost.09e9ffb7da404bcbb48e229a1e1309e3.x86.dll  : the native proxy for 32-bit Windows OS
 * ShellBoost.09e9ffb7da404bcbb48e229a1e1309e3.x64.dll  : the native proxy for 64-bit Windows OS
 * ShellBoost.Core.dll : the .NET assembly to reference in your .NET ShellBoost project, for 32-bit and 64-bit Windows OS (Built as 'Any Cpu')

Utility files:

 * ShellBoost.Cli.exe  : the .NET ShellBoost client. Contains a set of useful utilities to assist ShellBoost development, for 32-bit and 64-bit Windows OS (Built as 'Any Cpu')
 
License Id: 09e9ffb7da404bcbb48e229a1e1309e3
Expiration Date: 2019/07/13

This ShellBoost project has been licensed to: 
dilent.asat@gmail.com

Thank you for purchasing ShellBoost!

The ShellBoost Team.
Thursday, 17 January 2019 17:42:01
https://www.shellboost.com